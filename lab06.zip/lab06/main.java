class main{

public static void main(String[] args){


Dog d1 = new Dog();
d1.makesound(); 
}
}
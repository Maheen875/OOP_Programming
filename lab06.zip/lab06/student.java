class student extends person{

int studentID;

student(int studentID){
this.studentID = studentID;
}
}

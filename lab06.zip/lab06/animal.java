class animal{

String name;
int age;

public void makesound(){
}
}
class dog extends animal{

public void makesound(){
System.out.println("barking");
}
}
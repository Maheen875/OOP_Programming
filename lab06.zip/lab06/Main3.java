class Main3{
    public static void main(String args []){
   Car C = new Car("fortuner", 24, 4);
   C.showDetails();
   System.out.println();
   Bike B = new Bike("biko", 42, "Covered");
B.showDetails();

        
    }
    
}
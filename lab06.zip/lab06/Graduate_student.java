class GraduateStudent extends student{


String research_topic;
GraduateStudent(String  research_topic){
this. research_topic =  research_topic
}
}
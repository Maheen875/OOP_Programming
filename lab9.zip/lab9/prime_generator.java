import java.util.ArrayList;
import java.util.Random;

class RandomPrimeGenerator {

static void main(String[] args) {
        int min = 10;
        int max = 20;

        int randomPrime = generateRandomPrime(min, max);
        if (randomPrime != -1) {
            System.out.println("Random prime between " + min + " and " + max + ": " + randomPrime);
        } else {
            System.out.println("No prime numbers found in the given range.");
        }
    }

    public static int generateRandomPrime(int min, int max) {
        ArrayList<Integer> primes = new ArrayList<>();

        for (int i = min; i <= max; i++) {
            if (isPrime(i)) {
                primes.add(i);
            }
        }

        if (primes.isEmpty()) {
            return -1; // No prime found
        }

        Random rand = new Random();
        return primes.get(rand.nextInt(primes.size()));
    }

    public static boolean isPrime(int num) {
        if (num <= 1) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;

        for (int i = 3; i <= Math.sqrt(num); i += 2) {
            if (num % i == 0) return false;
        }

        return true;
    }
}

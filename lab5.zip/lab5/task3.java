class BankAccount {
    private double balance;
    private int accountNumber;

    
    public BankAccount(int accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

   
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

   
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient balance");
        }
    }

   
    public void checkBalance() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }

    public static void main(String[] args) {
        
        BankAccount acc1 = new BankAccount(12345, 1000);
        BankAccount acc2 = new BankAccount(67890, 500);

       
        acc1.deposit(500);
        acc2.deposit(1500);

       
        System.out.println("Account 1 Balance:");
        acc1.checkBalance();
        System.out.println("Account 2 Balance:");
        acc2.checkBalance();

        
        acc1.withdraw(500);
        acc1.checkBalance();

     
        acc2.withdraw(3000);
        acc2.checkBalance();
    }
}


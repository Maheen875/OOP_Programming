class Circle{
double radius;
String color;

public Circle(){}
public void calculateArea(){
   double area = 3.14159 *radius * radius;
System.out.println("Area of" + color + "circle:" + area);
}

public static void main(String args[]){
Circle red_circle= new Circle();

Circle green_circle= new Circle();

red_circle.radius = 5.5;
red_circle.color = "Red";

red_circle.radius = 3.7;
red_circle.color = "Green";

System.out.println("Radius of red circle:" + red_circle.radius );

System.out.println("Radius of green circle:" + green_circle.radius );


 red_circle.calculateArea();

green_circle.calculateArea();

}
}

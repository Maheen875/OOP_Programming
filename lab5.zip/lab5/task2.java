class Circle {
    double radius;
    String color;

    public Circle(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }

    public double calculateArea() {
        return 3.14159 * radius * radius;
    }

    public static void main(String[] args) {
       
        Circle red_circle = new Circle(5.5, "Red");
        Circle green_circle = new Circle(3.7, "Green");

        System.out.println("Radius of red circle: " + red_circle.radius);
        System.out.println("Radius of green circle: " + green_circle.radius);

   
        System.out.println("Area of red circle: " + red_circle.calculateArea());
        System.out.println("Area of green circle: " + green_circle.calculateArea());
    }
}


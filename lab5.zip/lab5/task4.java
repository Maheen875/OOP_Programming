 class Employee {
    String name;
    int yearOfJoining;
    double salary;
    String address;

    public Employee(String name, int yearOfJoining, double salary, String address) {
        this.name = name;
        this.yearOfJoining = yearOfJoining;
        this.salary = salary;
        this.address = address;
    }

    public void displayEmployeeInfo() {
        System.out.println("Name: " + name);
        System.out.println("Year_of_Joining: " + yearOfJoining);
        System.out.println("Address: " + address);
        System.out.println();
    }

    public static void main(String[] args) {
        
        Employee Aaron = new Employee("Aaron", 1994, 50000, "WallsStreat");
        Employee Zade = new Employee("Zade", 2000, 60000, "WallsStreat");
        Employee Tristan = new Employee("Tristan", 1999, 55000, "WallsStreat");

        Aaron.displayEmployeeInfo();
        Zade.displayEmployeeInfo();
        Tristan.displayEmployeeInfo();
    }
}



class task01{
public static void main(String[]args){
int []nums={3,1,4,9,5};

    int first =0;
    int second=0;

    for (int i=0; i< nums.length;i++){
      if(nums[i] > first) {
       second = first;
       first = nums[i];
}
else if (nums[i] > second && nums [i]!= first) {
     second = nums[i];
}
}
if (second == 0){
   System.out.println(-1);
}
else {
System.out.println(second);
}
}
}
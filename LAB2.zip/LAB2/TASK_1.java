import java.util.Scanner;

   class task1{

public static void main(String[]args){

Scanner input = new Scanner(System.in);
char [] constants = {'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};

char user_inp = input.next().charAt(0);
    

 boolean isConst = false;
        for (int i=0; i<constants.length; i++) {
            if (user_inp==constants[i]) {
                isConst = true;
                break;
            }
        }

        if (isConst) {
            System.out.println( " const");
        } else {
            System.out.println( " is not a consonant.");
        }


}
}



public class task5 {

    public static void main(String[] args) {
        // Create the matrix
        int[][] matrix ={ {1, 1, 0, 0},{1, 1, 0, 1},{0, 1, 0, 1},{1, 1, 0, 0},{1, 1, 1, 0}};

       
        System.out.println("Matrix:");
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        
        boolean containsN = checkLetterN(matrix);
        System.out.println("Matrix contains letter 'N': " + containsN);
    }

    
    public static boolean checkLetterN(int[][] matrix) {
        
        int[][] letterN = {{1, 1, 0, 0},{1, 0, 1, 0},{1, 0, 0, 1}, {1, 1, 1, 1} };

        
        for (int i = 0; i <= matrix.length - letterN.length; i++) {
            for (int j = 0; j <= matrix[i].length - letterN[0].length; j++) {
                if (matchLetterN(matrix, i, j, letterN)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static boolean matchLetterN(int[][] matrix, int row, int col, int[][] letterN) {
        for (int i = 0; i < letterN.length; i++) {
            for (int j = 0; j < letterN[i].length; j++) {
                if (matrix[row + i][col + j] != letterN[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }
}



import java.util.Scanner;

  public class Task1_a{

public static void main(String[]args){

char [] const_arr = {'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};

char character =scanner.next().charAt(0);
Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a character:");
        char user_inp = scanner.next().charAt(0);

 boolean isConsonant = false;
        for (char consonant : const_arr) {
            if (Character.toLowerCase(user_inp) == consonant) {
                isConsonant = true;
                break;
            }
        }

        if (isConsonant) {
            System.out.println(user_inp + " is a consonant.");
        } else {
            System.out.println(user_inp + " is not a consonant.");
        }









}
}
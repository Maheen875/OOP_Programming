import java.util.Scanner;

public class task6{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        String eligibility = (age >= 18) ? "Eligible" : "Not Eligible";
        System.out.println("You are " + eligibility + " for voting.");
        scanner.close();
    }
}

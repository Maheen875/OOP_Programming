class cat extends animal{
void makesound(){
     System.out.println("meow meow");
 }
}
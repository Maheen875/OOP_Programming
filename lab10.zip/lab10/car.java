 class car implement vehicle{
void start(){
System.out.println("car was start");
}

void stop(){
System.out.println("car was stop");
}
}
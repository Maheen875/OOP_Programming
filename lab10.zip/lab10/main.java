class main{


public static void main(String[] args){
dog d1 = new dog();
cat c1 = new cat();
d1.eat();
d1.makesound();
c1.eat();
c1.makesound();
}
}
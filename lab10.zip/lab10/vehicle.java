interface vehicle{
void start();
void stop();
}
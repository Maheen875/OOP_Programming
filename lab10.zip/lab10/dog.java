class dog extends animal{
 void makesound(){

     System.out.println( "bhaw bhaw");
 }
}
class main1{
public static void main(String[] args){
car my_car = new car();
bike my_bike = new bike();
my_car.start();
my_car.stop();
my_bike.start();
my_bike.stop();
}
}
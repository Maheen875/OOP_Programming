abstract class animal{
abstract void makesound();

void eat() {
     System.out.println( "animal is eating");
}
}

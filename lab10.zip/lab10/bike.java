class bike implement vehicle{
void start(){
System.out.println("bike was start");
}

void stop(){
System.out.println("bike was stop");
}
}
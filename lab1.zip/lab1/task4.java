class task4{
public static void main(String[]args){
  int num1 = 10;
  int num2 = 5;
  int num3 = 4;
  int num4 = 6;
System.out.print((num1+num2)*(num3-num4)/num3);
}
}
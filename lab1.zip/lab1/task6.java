import java.util.Scanner;

class currency{
   public static void main(String[]args){

Scanner myObj = new Scanner(System.in);
  double number;

System.out.println("enter number dollor");
number = myObj.nextDouble();
System.out.println("currency in" + (number*290));

}
}
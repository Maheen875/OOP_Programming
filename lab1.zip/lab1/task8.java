import java.util.Scanner;

  public class task7{

public static void main(String[]args){

 Scanner scanner = new Scanner (System.in);
double milesperhour;

System.out.println("enter speed in miles per hour:");
milesperhour = Scanner.nextDouble();
double kilometersperhour =milesperhour* 1.60934;

System.out.println(milesperhour + "mile per hour is equal to" + kilometersperhour + "kilometers per hour");

}
}


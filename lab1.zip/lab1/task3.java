public class task3{
String name;
int age;
double GPA;
String studentID;
char gender;
boolean isforeigner;

public static void main(String[]arguments){
StudentID student = new StudentID();
student.name = "Maheen";
student.age =21;
student.gpa =2.91;
student.studentID ="ari-f24-0048";
student.gender =F;
student.isforeigner =false;

System.out.println("Name:" + student.name);
System.out.println("Age:" + student.age);
System.out.println("GPA:" + student.gpa);
System.out.println("StudentID:" + student.studentID);
System.out.println("Gender:" + student.gender);
System.out.println("Is Foreigner:" + student.isforeigner);

}
}
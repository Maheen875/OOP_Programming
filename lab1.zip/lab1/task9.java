import java.util.Scanner;

  public class task9{

public static void main(String[]args){

 Scanner scanner = new Scanner (System.in); 

 
System.out.println("enter the first number :");
double num1 = Scanner.nextDouble();


System.out.println("enter any operations (+,-,*,/):");
char operations = Scanner.next().charAt(0);

System.out.println("enter the second number :");
double num2 = Scanner.nextDouble();

double result = 0;

switch(operations){
case'+':
result = num1+num2;
break;

case'-':
result = num1-num2;
break;

case'*':
result = num1n*um2;
break;

case'/':
result = num1/num2;
break;


}

}
}

















}
}
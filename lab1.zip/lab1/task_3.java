


public class Task3 {
    String name;
    int age;
    double gpa;
    String studentID;
    char gender;
    boolean isForeigner;

    public static void main(String[] arguments) {
        Task3 student = new Task3();
        student.name = "Maheen";
        student.age = 21;
        student.gpa = 2.91;
        student.studentID = "ari-f24-0048";
        student.gender = 'F'; 
        student.isForeigner = false;
        System.out.println("Name: " + student.name);
        System.out.println("Age: " + student.age);
        System.out.println("GPA: " + student.gpa);
        System.out.println("Student ID: " + student.studentID);
        System.out.println("Gender: " + student.gender);
        System.out.println("Is Foreigner: " + student.isForeigner);
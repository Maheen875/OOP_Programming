import java.util.Scanner;

  public class task7{

public static void main(String[]args){

  Scanner myObj = new Scanner (System.in);
System.out.print("enter the radius of the cylinder:");
  double radius = Scanner.nextDouble();

System.out.print("enter the height of the cylinder:");
 double height = Scanner.nextDouble();

 
 double volume = Math.PI*Math.pow(radius, 2)* height;

System.out.println("the volume of the cylinder is:" + volume);

}
}

 

 

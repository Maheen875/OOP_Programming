import java.util.Scanner;

  public class Task_9{

public static void main(String[]args){

 Scanner myObj = new Scanner (System.in); 
 int num1 = myObj.nextInt();
System.out.println("enter num1 :" + num1);
int num2 = myObj.nextInt();
System.out.println("enter num2 :" + num2);
System.out.println("enter any sign (+,-,*,/):");
char sign = myObj.next().charAt(0);

if(sign=='+')
{
System.out.println("addition =" +(num1+num2));
}
else if (sign=='-')
{
System.out.println("substraction =" +(num1-num2));
}
else if (sign=='*')
System.out.println("multiplication =" +(num1*num2));

else if (sign=='/')
{
System.out.println("division =" +(num1/num2));
}
else
{ 
System.out.println("entered sign not found, sorry!");
}
}

}